#include "AvlTree.h"

#include <stdio.h>

int main()
{
	AvlTree* bt = new AvlTree();

	bt->insert(50);
	bt->printAscii(bt->getRoot());
	bt->insert(25);
	bt->printAscii(bt->getRoot());
	bt->insert(75);
	bt->printAscii(bt->getRoot());
	bt->insert(12);
	bt->printAscii(bt->getRoot());
	bt->insert(37);
	bt->printAscii(bt->getRoot());
	bt->insert(0);
	bt->printAscii(bt->getRoot());

	//printf("Impressao: \n");
	//bt->printAscii(bt->getRoot());
	
    //printf("\nAdicionei o -1:\n");
	bt->insert(-1);
	bt->printAscii(bt->getRoot());

    bt->remove(25);
    printf("\n Removi o 25\n");
	bt->printAscii(bt->getRoot());
    bt->remove(50);
	printf("\n Removi o 50\n");
	bt->printAscii(bt->getRoot());

    bt->remove(12);
	printf("\n Removi o 12\n");
	bt->printAscii(bt->getRoot());
		
	delete bt;

	return 0;
}
