#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

using namespace std;

class MaxHeap
{
	private:
		int* h;
		int numElementos;
		int max;

	public:
		MaxHeap(int);//Construtor
		~MaxHeap();//Destrutor

		void subir(int);//Parâmetro é o índice do elemento cuja prioridade foi alterada
		void descer(int);

		void construirHeap();
		void preencheAleatorio(int);
		void imprimir();
		void inserir(int);
		int remover();
};