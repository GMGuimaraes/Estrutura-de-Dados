#include "MaxHeap.h"

int main()
{
	int max;

	cin >> max;

	//Cria o heap
	MaxHeap* heap = new MaxHeap(max);

	int num;

	cin >> num;

	//Preenche com valores aleatórios
	cout << "Vetor gerado aleatoriamente:\n";
	heap->preencheAleatorio(num); 
	heap->imprimir();

	//Transforma em heap
	cout << "Vetor transformado em heap:\n";
	heap->construirHeap();
	heap->imprimir();

	//Teste de inserção
	heap->inserir(110);
	heap->imprimir();

	heap->inserir(-1);
	heap->imprimir();

	heap->inserir(36);
	heap->imprimir();

	//Testes de remoção
	num = heap->remover();
	if (num != INT_MAX)
		cout << "Removi o " << num << endl;
	heap->imprimir();

	num = heap->remover();
	if (num != INT_MAX)
		cout << "Removi o " << num << endl;
	heap->imprimir();

	num = heap->remover();
	if (num != INT_MAX)
		cout << "Removi o " << num << endl;
	heap->imprimir();

	//Libera o heap
	delete heap;

	return 0;
}