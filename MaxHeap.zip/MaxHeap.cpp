#include "MaxHeap.h"

//Construtor: constrói um heap de tamanho máximo especificado no parâmetro
MaxHeap::MaxHeap(int max)
{
	h = new int[max];
	this->max = max;
	numElementos = 0;
}

//Destrutor: libera a memória alocada dinamicamente
MaxHeap::~MaxHeap()
{
	delete[] h;
}

//Método que sobe um elemento no heap
void MaxHeap::subir(int indice)
{
	int j, aux;

	//Verifico se não cheguei na raiz
	if (indice > 0)
	{
		//Calculo o índice do pai
		j = (indice - 1) / 2;

		//Verifico se o filho é maior do que o pai, se for viola a restrição
		//e preciso trocar
		if (h[indice] > h[j])
		{//Troco
			aux = h[indice];
			h[indice] = h[j];
			h[j] = aux;

			subir(j);
		}
	}
}

//Método que desce um elemento no heap
void MaxHeap::descer(int indice)
{
	int j, aux;

	//Calcula o índice do filho da esquerda
	j = 2 * indice + 1;

	//Verifica se o filho da esquerda existe, se não existir, estamos em uma folha
	if (j < numElementos)
	{//Filho da esquerda existe
		//Verifica se o filho da direita existe
		if (j + 1 < numElementos)
		{
			//Tem os dois filhos
			//Acha o maior e faz j ser o índice desse elemento
			if (h[j + 1] > h[j])
				j++;
		}
		//j é o índice do maior filho
		if (h[indice] < h[j])//Verifica se a restrição é violada
		{//Troca se há violação
			aux = h[indice];
			h[indice] = h[j];
			h[j] = aux;

			descer(j);
		}
	}
}

//Método para transformar o vetor h em um heap
void MaxHeap::construirHeap()
{
	int ultimo = numElementos / 2 - 1;

	for (int i = ultimo; i >= 0; i--)
		descer(i);
}

void MaxHeap::preencheAleatorio(int num)
{
	numElementos = num;

	srand(time(0));

	for (int i = 0; i < numElementos; i++)
		h[i] = rand() % 101; 
}

void MaxHeap::imprimir()
{
	if (numElementos == 0)
		cout << "Heap vazio!";
	else
		for (int i = 0; i < numElementos; i++)
			cout << h[i] << " ";

	cout << endl;
}

void MaxHeap::inserir(int p)
{
	if (numElementos < max)//Tem espaço
	{
		h[numElementos] = p;

		subir(numElementos++);
	}
	else
		cout << "Overflow\n";
}

int MaxHeap::remover()
{
	int val = INT_MAX;

	if (numElementos > 0)
	{
		val = h[0];
		h[0] = h[--numElementos];

		descer(0);
	}
	else
		cout << "Underflow\n";

	return val;
}