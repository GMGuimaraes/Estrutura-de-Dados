//Define a estrutura de um nó de listas duplamente encadeadas
struct node
{
	int chave;
	node* ant;
	node* prox;
};
