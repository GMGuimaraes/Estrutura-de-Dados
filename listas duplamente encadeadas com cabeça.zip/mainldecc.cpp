#include "ldecc.h"

int main()
{
	ldecc* lista = cria_nova_ldecc();
	
	imprime_ldecc(lista);
	
	insere_antes_ldecc(lista, 10, 1000);
	imprime_ldecc(lista);
	
	insere_antes_ldecc(lista, 20, 1000);
	imprime_ldecc(lista);
	
	insere_antes_ldecc(lista, 30, 20);
	imprime_ldecc(lista);
	
	insere_antes_ldecc(lista, 40, 10);
	imprime_ldecc(lista);
	
	/*if (busca_ldecc(lista, 10))
		printf("Chave encontrada!\n");
	else
		printf("Chave não encontrada!\n");*/
		
	remove_chave_ldecc(lista, 10);
	imprime_ldecc(lista);
	
	remove_chave_ldecc(lista, 20);
	imprime_ldecc(lista);
	
	remove_chave_ldecc(lista, 40);
	imprime_ldecc(lista);
	
	remove_chave_ldecc(lista, 30);
	imprime_ldecc(lista);
	
	insere_antes_ldecc(lista, 50, 1000);
	imprime_ldecc(lista);
	
	return 0;
}
