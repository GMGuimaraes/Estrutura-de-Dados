#include "filacc.h"

int main()
{
	filacc* fila = cria_fila();
	imprime(fila);

	enfileira(fila, 10);
	imprime(fila);

	enfileira(fila, 20);
	imprime(fila);	

	enfileira(fila, 30);
	imprime(fila);

	enfileira(fila, 40);
	imprime(fila);

	enfileira(fila, 50);
	imprime(fila);

	int num = desenfileira(fila);
	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	enfileira(fila, 60);
	imprime(fila);

	num = desenfileira(fila);

	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	num = desenfileira(fila);

	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	num = desenfileira(fila);

	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	num = desenfileira(fila);

	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	num = desenfileira(fila);

	if (num != INT_MAX)
		printf("Desenfileirei o %d\n", num);
	imprime(fila);

	enfileira(fila, 70);
	imprime(fila);

	enfileira(fila, 80);
	imprime(fila);

	return 0;
}