struct no
{
	int chave;
	no* prox;	
};