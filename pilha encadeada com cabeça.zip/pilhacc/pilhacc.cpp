#include "pilhacc.h"

pilhacc* cria_pilha()
{
	pilhacc* p = new pilhacc;

	p->cabeca = new no;
	p->cabeca->prox = NULL;

	return p;
}

void imprime(pilhacc* p)
{
	if (p->cabeca->prox == NULL)//A pilha está vazia
		printf("Pilha vazia!");
	else
		for (no* ptr = p->cabeca->prox; ptr; ptr = ptr->prox)
			printf("%d ", ptr->chave);

	printf("\n");
}

void empilha(pilhacc* p, int novoValor)
{
	no* novo = new no;

	novo->chave = novoValor;
	novo->prox = p->cabeca->prox;

	p->cabeca->prox = novo;
}

int desempilha(pilhacc* p)
{
	int x = INT_MAX;
	no* ptr = p->cabeca->prox;

	if (ptr)
	{
		x = ptr->chave;
		p->cabeca->prox = ptr->prox;

		delete ptr; 
	}
	else
		printf("Pilha vazia!\n");

	return x;
}

void libera_pilha(pilhacc* p)
{
	no *ptr, *aux;

	aux = p->cabeca->prox;

	while (aux != NULL)
	{
		ptr = aux;
		aux = aux->prox;

		delete ptr;
	}

	delete p->cabeca;

	delete p;
}