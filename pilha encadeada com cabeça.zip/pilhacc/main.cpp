#include "pilhacc.h"

int main()
{
	pilhacc* pilha = cria_pilha();
	imprime(pilha);

	empilha(pilha, 10);
	imprime(pilha);	

	empilha(pilha, 20);
	imprime(pilha);	

	empilha(pilha, 30);
	imprime(pilha);	

	empilha(pilha, 40);
	imprime(pilha);	

	empilha(pilha, 50);
	imprime(pilha);	

	empilha(pilha, 60);
	imprime(pilha);	

	int num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);

	num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);

	num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);

	num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);

	num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);

	num = desempilha(pilha);
	if (num != INT_MAX)
		printf("Desempilhei %d\n", num);
	imprime(pilha);	

	empilha(pilha, 70);
	imprime(pilha);

	libera_pilha(pilha);

	return 0;
}