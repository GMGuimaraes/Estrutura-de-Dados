#include "no.h"
#include <stdio.h>
#include <limits.h>

struct pilhacc
{
	no* cabeca;
};

//Prototipações
pilhacc* cria_pilha();
void imprime(pilhacc*);
void empilha(pilhacc*, int);
int desempilha(pilhacc*);
void libera_pilha(pilhacc*);