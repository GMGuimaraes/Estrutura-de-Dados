#include "node.h"
#include <iostream>

using namespace std;

class BinaryTree
{
	public:
		Node* root;

		//Construtor
		BinaryTree()
		{
			root = 0;
		}

		//Percursos
		void preOrder(Node*);
		void inOrder(Node*);
		void posOrder(Node*);


		//Visita
		void visit(Node*);

		//Cálculo da altura
		void posOrderHeight(Node*);
		void heightNode(Node*);

		Node* findNode(int, Node*&);

		bool addNode(int);
		void doAddNode(int, Node*);

		bool removeNode(int);
		void doRemoveNode(Node*, Node*);
};
