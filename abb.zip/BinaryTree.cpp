#include "BinaryTree.h"

void BinaryTree::preOrder(Node* node)
{
	if (node)
	{
		visit(node);
		preOrder(node->left);
		preOrder(node->right);
	}
}

void BinaryTree::inOrder(Node* node)
{
	if (node)
	{
		inOrder(node->left);
		visit(node);
		inOrder(node->right);
	}
}

void BinaryTree::posOrder(Node* node)
{
	if (node)
	{
		posOrder(node->left);
		posOrder(node->right);
		visit(node);
	}
}

void BinaryTree::visit(Node* node)
{
	cout << node->info << " ";
}

void BinaryTree::posOrderHeight(Node* node)
{
	if (node)
	{
		posOrderHeight(node->left);
		posOrderHeight(node->right);
		heightNode(node);
	}
}

void BinaryTree::heightNode(Node* node)
{
	int alt1, alt2;

	if (node->left)
		alt1 = node->left->height;
	else
		alt1 = 0;

	if (node->right)
		alt2 = node->right->height;
	else
		alt2 = 0;

	if (alt1 > alt2)
		node->height = alt1 + 1;
	else
		node->height = alt2 + 1;	
}

Node* BinaryTree::findNode(int value, Node*& parent)
{
	Node* cur = root;

	while (cur)
	{
		if (cur->info == value)
			return cur;

		//Não achei, tenho que descer na árvore
		parent = cur;
		if (value < cur->info)
			cur = cur->left;
		else
			cur = cur->right;
	}

	return cur;
}

bool BinaryTree::addNode(int value)
{
	Node* parent = 0;

	Node* cur = findNode(value, parent);

	if (!cur)
	{
		doAddNode(value, parent);

		return true;
	}


	return false;
}

void BinaryTree::doAddNode(int value, Node* parent)
{
	if (parent)
	{
		if (value < parent->info)
			parent->left = new Node(value);
		else
			parent->right = new Node(value);
	}
	else
		root = new Node(value);
}

bool BinaryTree::removeNode(int value)
{
	Node* parent = 0;
	Node* node = findNode(value, parent);

	if (node)
	{
		doRemoveNode(node, parent);

		return true;
	}

	return false;
}

void BinaryTree::doRemoveNode(Node* node, Node* parent)
{
	Node* y;
	Node* py;
	Node* x;

	if (!node->left || !node->right)
	{
		//Tem 0 ou 1 filho
		y = node;
		py = parent;
	}
	else
	{//Tem dois filhos, preciso encontrar o menor valor da subárvore da direita
		py = node;
		y = node->right;

		while (y->left)
		{
			py = y;
			y = y->left;
		}
	}

	//Vou fazer x apontar para o único filho de y, se existir
	if (y->left)
		x = y->left;
	else
		x = y->right;


	//Removo o y
	if (py)
	{
		if (y == py->left)
			py->left = x;
		else
			py->right = x;
	}
	else//Estou removendo a raiz
		root = x;

	if (y != node)
		node->info = y->info;

	delete y;
}