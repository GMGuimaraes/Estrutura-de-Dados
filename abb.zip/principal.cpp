#include "BinaryTree.h"

int main()
{
	BinaryTree* tree = new BinaryTree();

	tree->preOrder(tree->root);
	cout << endl;

	tree->addNode(30);
	tree->preOrder(tree->root);
	cout << endl;

	tree->addNode(10);
	tree->preOrder(tree->root);
	cout << endl;	

	tree->addNode(40);
	tree->preOrder(tree->root);
	cout << endl;

	tree->addNode(20);
	tree->preOrder(tree->root);
	cout << endl;

	tree->addNode(50);
	tree->preOrder(tree->root);
	cout << endl;

	tree->addNode(50);
	tree->preOrder(tree->root);
	cout << endl;

	tree->removeNode(20);
	tree->preOrder(tree->root);
	cout << endl;

	tree->removeNode(40);
	tree->preOrder(tree->root);
	cout << endl;

	tree->removeNode(30);
	tree->preOrder(tree->root);
	cout << endl;

	delete tree;

	return 0;
}