#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "BTree.h"

int main()
{
    //Cria uma B-árvore com ordem 2
    BTree* tree = new BTree(2);

    //Insere algumas chaves
    tree->insert(1);
    tree->insert(2);
    tree->insert(3);
    tree->insert(4);
    tree->insert(5);
    tree->insert(6);
    tree->insert(7);
    tree->insert(8);
    tree->insert(9);
    tree->insert(10);
    tree->insert(0);
    tree->insert(-1);
    tree->insert(-2);
    tree->insert(-3);
    tree->insert(-4);

    printf("\n");
    //Imprime por nível
    tree->levelTraversal();
   
    //Remove uma chave
    tree->remove(4);
    printf("\n");
    tree->levelTraversal();
    printf("\n");

    delete tree;

    return 0;
}
